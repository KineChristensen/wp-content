<?php
/*
Plugin Name:  Responsive Filterable Posts/Custom Posts
Version:      1.0.1
Author:       DesirePress
Author URI:   https://desirepress.com
Description:  This is a Awesome plugin provide a very modern & Responsive filterable Grid for Posts/Custom Posts based on Isotope/Masonary layout.
License:      GNU General Public License v2.0
License URI:  http://www.gnu.org/licenses/gpl-2.0.html
*/
include_once('rfp-class.php');
include_once('inc/rfp-cpt.php');
include_once('inc/rfp-shortcode.php');
$rfpobj = new Rfp_Class(); 
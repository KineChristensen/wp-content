<?php
// Silence is golden.